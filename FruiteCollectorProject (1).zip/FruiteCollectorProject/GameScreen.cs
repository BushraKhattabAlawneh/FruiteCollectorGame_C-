﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FruiteCollectorProject
{
    public partial class GameScreen : Form
    {
        bool moveright, moveleft, moveup, movedown;
        int speed = 10;
        int score = 0;
        int timeLeft1 =200;


        public GameScreen()
        {
            InitializeComponent();
            basket.BackColor = Color.Transparent;
            mango.BackColor = Color.Transparent;
            cherry.BackColor = Color.Transparent;
            strawberry.BackColor = Color.Transparent;
            plum.BackColor = Color.Transparent;
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void GameScreen_Load(object sender, EventArgs e)
        {
              
        }

        private void gameToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void newToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void profileToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void gametimer_Tick(object sender, EventArgs e)
        {
            if (score == 75)
            {
                gametimer.Stop();
                MessageBox.Show("You achieved the goal.", "Congratulations!");
                
            }
            if (timeLeft1 > 0)
            {
                timeLeft1 = timeLeft1 - 1;
                timeLabel.Text = timeLeft1 + " seconds";
            }
            if(timeLeft1 <= 0)
            {
                gametimer.Stop();
                timeLabel.Text = "Time's up!";
                MessageBox.Show("You didn't finish in time.", "Sorry!");
            }

            scoregame.Text = "Score: " + score;

            if (moveleft == true && basket.Left >0 )
            {
                basket.Left -= speed;
            }
            if (moveright == true && basket.Left < 700)
            {
                basket.Left += speed;
            }
            if (moveup == true && basket.Top > 0)
            {
                basket.Top -= speed;
            }
            if (movedown == true && basket.Top < 369)
            {
                basket.Top += speed;
            }

            foreach (Control fruit in this.Controls)
            {

                if (fruit is PictureBox &&fruit.Tag == "fruits")
                {
                    if (((PictureBox)fruit).Bounds.IntersectsWith(basket.Bounds))
                    {
                        this.Controls.Remove(fruit);
                        score+=5;
                    }
                }
            }
        }

        private void banana_Click(object sender, EventArgs e)
        {

        }

        private void basket_Click(object sender, EventArgs e)
        {

        }

        private void GameScreen_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Up)
            {
                moveup = true;
            }
            if (e.KeyCode == Keys.Down)
            {
                movedown = true;
            }
            if (e.KeyCode == Keys.Left)
            {
                moveleft = true;
            }
            if (e.KeyCode == Keys.Right)
            {
                moveright = true;
            }
        }

        private void GameScreen_KeyUp(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Up)
            {
                moveup = false;
            }
            if (e.KeyCode == Keys.Down)
            {
                movedown = false;
            }
            if (e.KeyCode == Keys.Left)
            {
                moveleft = false;
            }
            if (e.KeyCode == Keys.Right)
            {
                moveright = false;
            }
        }

        
    
    }
}
