﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FruitCollectorProject
{
    static class Program
    {
        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        

        //DB Area

        static public StatisticsInfo gameStatistics;
        static public List<GameInfo> game;
        static public GameInfo GamePlayerInfo;
        static public List<PlayerInfo> profilesList;
        static public PlayerInfo CurrentPlayerInfo;

        [STAThread]
        static void Main()
        {
            profilesList = new List<PlayerInfo>();
            game = new List<GameInfo>();
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new Welcome());
        }
    }
}
