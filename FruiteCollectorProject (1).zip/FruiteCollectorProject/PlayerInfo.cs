﻿using System;


namespace FruitCollectorProject
{
    public class PlayerInfo
    {
        public String name { get; set; }
        public String gender { get; set; }
        public String age { get; set; }
        public String backgroundColor { get; set; }

        public PlayerHistory history;



        public PlayerInfo ( string name , string gender, string age, string backgroundColor)
        {

            this.name = name;
            this.gender = gender;
            this.age = age;
            this.backgroundColor = backgroundColor;

            this.history = new PlayerHistory();
        }

    }
}
