﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FruitCollectorProject
{
    class StatisticsInfo
    {
        int highest { set; get; }
        int lowest { set; get; }
        int maxDuration { set; get; }
        int minDuration { set; get; }
        int totalDuration { set; get; }

        public StatisticsInfo()
        {
            highest = 0;
            lowest = 0;
            maxDuration = 0;
            minDuration = 0;
            totalDuration = 0;
        }
    }
}
