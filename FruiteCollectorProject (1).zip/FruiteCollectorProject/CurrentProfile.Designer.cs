﻿
namespace FruiteCollectorProject
{
    partial class CurrentProfile
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label2 = new System.Windows.Forms.Label();
            this.CreateProfile = new System.Windows.Forms.LinkLabel();
            this.current = new System.Windows.Forms.Label();
            this.profilesBox = new System.Windows.Forms.ComboBox();
            this.Startgame = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("MV Boli", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.Maroon;
            this.label2.Location = new System.Drawing.Point(299, 30);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(177, 40);
            this.label2.TabIndex = 2;
            this.label2.Text = "New Game";
            // 
            // CreateProfile
            // 
            this.CreateProfile.AutoSize = true;
            this.CreateProfile.LinkColor = System.Drawing.Color.Red;
            this.CreateProfile.Location = new System.Drawing.Point(340, 361);
            this.CreateProfile.Name = "CreateProfile";
            this.CreateProfile.Size = new System.Drawing.Size(90, 17);
            this.CreateProfile.TabIndex = 3;
            this.CreateProfile.TabStop = true;
            this.CreateProfile.Text = "Create one ?";
            this.CreateProfile.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.CreateProfile_LinkClicked);
            // 
            // current
            // 
            this.current.AutoSize = true;
            this.current.Font = new System.Drawing.Font("MV Boli", 19.8F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.current.ForeColor = System.Drawing.Color.Maroon;
            this.current.Location = new System.Drawing.Point(12, 172);
            this.current.Name = "current";
            this.current.Size = new System.Drawing.Size(279, 44);
            this.current.TabIndex = 4;
            this.current.Text = "Current Profile :";
            // 
            // profilesBox
            // 
            this.profilesBox.FormattingEnabled = true;
            this.profilesBox.Location = new System.Drawing.Point(322, 191);
            this.profilesBox.Name = "profilesBox";
            this.profilesBox.Size = new System.Drawing.Size(262, 24);
            this.profilesBox.TabIndex = 5;
            // 
            // Startgame
            // 
            this.Startgame.BackColor = System.Drawing.Color.Maroon;
            this.Startgame.Font = new System.Drawing.Font("MV Boli", 9F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Startgame.ForeColor = System.Drawing.Color.White;
            this.Startgame.Location = new System.Drawing.Point(306, 312);
            this.Startgame.Name = "Startgame";
            this.Startgame.Size = new System.Drawing.Size(170, 35);
            this.Startgame.TabIndex = 6;
            this.Startgame.Text = "Start The Game";
            this.Startgame.UseVisualStyleBackColor = false;
            this.Startgame.Click += new System.EventHandler(this.Startgame_Click);
            // 
            // CurrentProfile
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.LemonChiffon;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.Startgame);
            this.Controls.Add(this.profilesBox);
            this.Controls.Add(this.current);
            this.Controls.Add(this.CreateProfile);
            this.Controls.Add(this.label2);
            this.Name = "CurrentProfile";
            this.Text = "CurrentProfile";
            this.Load += new System.EventHandler(this.CurrentProfile_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.LinkLabel CreateProfile;
        private System.Windows.Forms.Label current;
        private System.Windows.Forms.ComboBox profilesBox;
        private System.Windows.Forms.Button Startgame;
    }
}