﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FruitCollectorProject
{
    public partial class History : Form
    {
        public History()
        {
            InitializeComponent();
        }

        private void History_Load(object sender, EventArgs e)
        {
            dataGridViewHistory.RowCount = Program.profilesList.Count;

            int x = Program.profilesList.Count;

            for (int i = 0; i < x ; i++)
            {
                dataGridViewHistory.Rows[i].Cells["name"].Value = Program.profilesList.ElementAt(i).name;
                dataGridViewHistory.Rows[i].Cells["date"].Value = Program.profilesList.ElementAt(i).history.Date;
                dataGridViewHistory.Rows[i].Cells["duration"].Value = Program.profilesList.ElementAt(i).history.Duration;
                dataGridViewHistory.Rows[i].Cells["score"].Value = Program.profilesList.ElementAt(i).history.Score;
                dataGridViewHistory.Rows[i].Cells["levels"].Value = Program.profilesList.ElementAt(i).history.Levels;
           
            }

        }

        private void newToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Hide();
            GameScreen g = new GameScreen();
            g.Show();
        }

        private void endToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Hide();
            Welcome w = new Welcome();
            w.Show();
        }

        private void currentToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Hide();
            CurrentProfile cp = new CurrentProfile();
            cp.Show();
        }

        private void newToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            this.Hide();
            Profile p = new Profile();
            p.Show();
        }

        private void statisticsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Hide();
            Statistics s = new Statistics();
            s.Show();
        }

        private void historyToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Hide();
            History h = new History();
            h.Show();
        }

        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}
