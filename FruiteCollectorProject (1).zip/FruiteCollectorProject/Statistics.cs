﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FruitCollectorProject
{
    public partial class Statistics : Form
    {
        public Statistics()
        {
            
            InitializeComponent();
        }


        List<int> scores = new List<int>();
        private void Statistics_Load(object sender, EventArgs e)
        {
            //noGames.Text = Program

            noGames.Text = Program.game.Count.ToString();
            noProfiles.Text = Program.profilesList.Count.ToString();

          
            var result = from s in Program.profilesList
                         select s.history.Duration;
            minDuration.Text= result.ToList().Min().ToString();
            maxDuration.Text = result.ToList().Max().ToString();

            totalDuration.Text = result.ToList().Sum().ToString();
            
            var resutlt2 = from s in Program.profilesList
                         select s.history.Score;
            highestScore.Text = resutlt2.ToList().Max().ToString();
            LowestScore.Text = resutlt2.ToList().Min().ToString();


            //int Hscore = scores.Max();
            //highestScore.Text = Hscore.ToString();
        }

        private void newToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Hide();
            GameScreen g = new GameScreen();
            g.Show();
        }

        private void endToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Hide();
            Welcome w = new Welcome();
            w.Show();
        }

        private void currentToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Hide();
            CurrentProfile cp = new CurrentProfile();
            cp.Show();
        }

        private void newToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            this.Hide();
            Profile p = new Profile();
            p.Show();
        }

        private void statisticsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Hide();
            Statistics s = new Statistics();
            s.Show();
        }

        private void historyToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Hide();
            History h = new History();
            h.Show();
        }

        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}
