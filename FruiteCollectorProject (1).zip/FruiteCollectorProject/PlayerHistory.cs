﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FruitCollectorProject
{
    public class PlayerHistory
    {
        public int Duration{ get; set; }
        public int Score { get; set; }
        public int Levels { get; set; }
        public String Date { get; set; }
        public PlayerHistory()
        {
            this.Duration = 0;
            this.Score = 0;
            this.Levels = 0;
            this.Date = DateTime.Now.ToString("MM-dd-yyyy");
        }

    }
}
