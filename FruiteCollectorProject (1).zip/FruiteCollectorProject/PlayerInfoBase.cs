﻿namespace FruitCollectorProject
{
    public class PlayerInfoBase
    {

       public PlayerHistory PlayerHistory { get; set; }
    }
}