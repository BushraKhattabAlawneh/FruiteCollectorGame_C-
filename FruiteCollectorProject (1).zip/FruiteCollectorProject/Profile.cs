﻿using System;
using System.Windows.Forms;

namespace FruitCollectorProject
{
   
    public partial class Profile : Form
    {
        String _name, _gender, _age, _backgroundColor;
        public Profile()
        {
            InitializeComponent();
        }

        private void newToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Hide();
            GameScreen g = new GameScreen();
            g.Show();
        }

        private void endToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Hide();
            Welcome w = new Welcome();
            w.Show();
        }

        private void currentToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Hide();
            CurrentProfile cp = new CurrentProfile();
            cp.Show();
        }

        private void newToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            this.Hide();
            Profile p = new Profile();
            p.Show();
        }

        private void statisticsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Hide();
            Statistics s = new Statistics();
            s.Show();
        }

        private void historyToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Hide();
            History h = new History();
            h.Show();
        }

        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        public PlayerInfo CurrentPlayerInfo { get; private set; }

        private void Profile_Load(object sender, EventArgs e)
        {

        }
        private void SaveProfile_Click(object sender, EventArgs e)
        {
            _name = nametxt.Text;

            _gender = "";
            if(male.Checked)
            {
                _gender = male.Text;
            }
            else if (female.Checked)
            {
                _gender = female.Text;
            }

            _age = cbage.Text;

            _backgroundColor = "";
            if (farmBackground.Checked)
            {
                _backgroundColor = farmBackground.Text;
            }
            else if (LemonBackground.Checked)
            {
                _backgroundColor = LemonBackground.Text;
            }
            else if (SkyBlueBackground.Checked)
            {
                _backgroundColor = SkyBlueBackground.Text;
            }


            //_gender = "mail";
            //_backgroundColor = "kkk";

            Program.CurrentPlayerInfo = new PlayerInfo(_name , _gender, _age, _backgroundColor);
            Program.profilesList.Add(Program.CurrentPlayerInfo) ;

            CurrentProfile cp = new CurrentProfile();

            this.Hide();
            cp.Show();
        }

    }

        }
  
    

