﻿
namespace FruiteCollectorProject
{
    partial class GameScreen
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.gameToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.newToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.endToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.profileToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.currentToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.newToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.reportToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.statisticsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.historyToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.exitToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.GameName = new System.Windows.Forms.Label();
            this.contextMenuStrip1 = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.basket = new System.Windows.Forms.PictureBox();
            this.scoregame = new System.Windows.Forms.Label();
            this.strawberry = new System.Windows.Forms.PictureBox();
            this.plum = new System.Windows.Forms.PictureBox();
            this.mango = new System.Windows.Forms.PictureBox();
            this.cherry = new System.Windows.Forms.PictureBox();
            this.gametimer = new System.Windows.Forms.Timer(this.components);
            this.lemon = new System.Windows.Forms.PictureBox();
            this.peach = new System.Windows.Forms.PictureBox();
            this.guava = new System.Windows.Forms.PictureBox();
            this.banana = new System.Windows.Forms.PictureBox();
            this.custardapple = new System.Windows.Forms.PictureBox();
            this.rasberry = new System.Windows.Forms.PictureBox();
            this.durian = new System.Windows.Forms.PictureBox();
            this.papaya = new System.Windows.Forms.PictureBox();
            this.lychee = new System.Windows.Forms.PictureBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.timeLabel = new System.Windows.Forms.Label();
            this.menuStrip1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.basket)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.strawberry)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.plum)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.mango)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.cherry)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.lemon)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.peach)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.guava)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.banana)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.custardapple)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.rasberry)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.durian)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.papaya)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.lychee)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.menuStrip1.AutoSize = false;
            this.menuStrip1.BackColor = System.Drawing.Color.White;
            this.menuStrip1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.menuStrip1.Dock = System.Windows.Forms.DockStyle.None;
            this.menuStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.gameToolStripMenuItem,
            this.profileToolStripMenuItem,
            this.reportToolStripMenuItem,
            this.exitToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(496, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(304, 37);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "Menu";
            // 
            // gameToolStripMenuItem
            // 
            this.gameToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.newToolStripMenuItem,
            this.endToolStripMenuItem});
            this.gameToolStripMenuItem.Font = new System.Drawing.Font("MV Boli", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gameToolStripMenuItem.ForeColor = System.Drawing.Color.Maroon;
            this.gameToolStripMenuItem.Name = "gameToolStripMenuItem";
            this.gameToolStripMenuItem.Size = new System.Drawing.Size(67, 33);
            this.gameToolStripMenuItem.Text = "Game";
            this.gameToolStripMenuItem.Click += new System.EventHandler(this.gameToolStripMenuItem_Click);
            // 
            // newToolStripMenuItem
            // 
            this.newToolStripMenuItem.ForeColor = System.Drawing.Color.Maroon;
            this.newToolStripMenuItem.Name = "newToolStripMenuItem";
            this.newToolStripMenuItem.Size = new System.Drawing.Size(127, 26);
            this.newToolStripMenuItem.Text = "New";
            this.newToolStripMenuItem.Click += new System.EventHandler(this.newToolStripMenuItem_Click);
            // 
            // endToolStripMenuItem
            // 
            this.endToolStripMenuItem.ForeColor = System.Drawing.Color.Maroon;
            this.endToolStripMenuItem.Name = "endToolStripMenuItem";
            this.endToolStripMenuItem.Size = new System.Drawing.Size(127, 26);
            this.endToolStripMenuItem.Text = "End";
            // 
            // profileToolStripMenuItem
            // 
            this.profileToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.currentToolStripMenuItem,
            this.newToolStripMenuItem1});
            this.profileToolStripMenuItem.Font = new System.Drawing.Font("MV Boli", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.profileToolStripMenuItem.ForeColor = System.Drawing.Color.Maroon;
            this.profileToolStripMenuItem.Name = "profileToolStripMenuItem";
            this.profileToolStripMenuItem.Size = new System.Drawing.Size(74, 33);
            this.profileToolStripMenuItem.Text = "Profile";
            this.profileToolStripMenuItem.Click += new System.EventHandler(this.profileToolStripMenuItem_Click);
            // 
            // currentToolStripMenuItem
            // 
            this.currentToolStripMenuItem.ForeColor = System.Drawing.Color.Maroon;
            this.currentToolStripMenuItem.Name = "currentToolStripMenuItem";
            this.currentToolStripMenuItem.Size = new System.Drawing.Size(153, 26);
            this.currentToolStripMenuItem.Text = "Current";
            // 
            // newToolStripMenuItem1
            // 
            this.newToolStripMenuItem1.ForeColor = System.Drawing.Color.Maroon;
            this.newToolStripMenuItem1.Name = "newToolStripMenuItem1";
            this.newToolStripMenuItem1.Size = new System.Drawing.Size(153, 26);
            this.newToolStripMenuItem1.Text = "New";
            // 
            // reportToolStripMenuItem
            // 
            this.reportToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.statisticsToolStripMenuItem,
            this.historyToolStripMenuItem});
            this.reportToolStripMenuItem.Font = new System.Drawing.Font("MV Boli", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.reportToolStripMenuItem.ForeColor = System.Drawing.Color.Maroon;
            this.reportToolStripMenuItem.Name = "reportToolStripMenuItem";
            this.reportToolStripMenuItem.Size = new System.Drawing.Size(79, 33);
            this.reportToolStripMenuItem.Text = "Report";
            // 
            // statisticsToolStripMenuItem
            // 
            this.statisticsToolStripMenuItem.ForeColor = System.Drawing.Color.Maroon;
            this.statisticsToolStripMenuItem.Name = "statisticsToolStripMenuItem";
            this.statisticsToolStripMenuItem.Size = new System.Drawing.Size(168, 26);
            this.statisticsToolStripMenuItem.Text = "Statistics";
            // 
            // historyToolStripMenuItem
            // 
            this.historyToolStripMenuItem.ForeColor = System.Drawing.Color.Maroon;
            this.historyToolStripMenuItem.Name = "historyToolStripMenuItem";
            this.historyToolStripMenuItem.Size = new System.Drawing.Size(168, 26);
            this.historyToolStripMenuItem.Text = "History";
            // 
            // exitToolStripMenuItem
            // 
            this.exitToolStripMenuItem.Font = new System.Drawing.Font("MV Boli", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.exitToolStripMenuItem.ForeColor = System.Drawing.Color.Maroon;
            this.exitToolStripMenuItem.Name = "exitToolStripMenuItem";
            this.exitToolStripMenuItem.Size = new System.Drawing.Size(55, 33);
            this.exitToolStripMenuItem.Text = "Exit";
            this.exitToolStripMenuItem.Click += new System.EventHandler(this.exitToolStripMenuItem_Click);
            // 
            // GameName
            // 
            this.GameName.AutoSize = true;
            this.GameName.BackColor = System.Drawing.Color.White;
            this.GameName.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.GameName.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.GameName.Font = new System.Drawing.Font("MV Boli", 16.2F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.GameName.ForeColor = System.Drawing.Color.Maroon;
            this.GameName.Location = new System.Drawing.Point(1, 0);
            this.GameName.Name = "GameName";
            this.GameName.Size = new System.Drawing.Size(225, 37);
            this.GameName.TabIndex = 1;
            this.GameName.Text = "Fruit Collector";
            this.GameName.Click += new System.EventHandler(this.label1_Click);
            // 
            // contextMenuStrip1
            // 
            this.contextMenuStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.contextMenuStrip1.Name = "contextMenuStrip1";
            this.contextMenuStrip1.Size = new System.Drawing.Size(61, 4);
            // 
            // basket
            // 
            this.basket.Image = global::FruiteCollectorProject.Properties.Resources.icons8_wicker_basket_48__1_;
            this.basket.Location = new System.Drawing.Point(721, 369);
            this.basket.Name = "basket";
            this.basket.Size = new System.Drawing.Size(67, 69);
            this.basket.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.basket.TabIndex = 2;
            this.basket.TabStop = false;
            this.basket.Click += new System.EventHandler(this.basket_Click);
            // 
            // scoregame
            // 
            this.scoregame.AutoSize = true;
            this.scoregame.Font = new System.Drawing.Font("MV Boli", 10.2F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.scoregame.Location = new System.Drawing.Point(4, 59);
            this.scoregame.Name = "scoregame";
            this.scoregame.Size = new System.Drawing.Size(51, 22);
            this.scoregame.TabIndex = 3;
            this.scoregame.Text = "Score";
            // 
            // strawberry
            // 
            this.strawberry.Image = global::FruiteCollectorProject.Properties.Resources.icons8_strawberry_48;
            this.strawberry.Location = new System.Drawing.Point(573, 234);
            this.strawberry.Name = "strawberry";
            this.strawberry.Size = new System.Drawing.Size(38, 35);
            this.strawberry.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.strawberry.TabIndex = 4;
            this.strawberry.TabStop = false;
            this.strawberry.Tag = "fruits";
            // 
            // plum
            // 
            this.plum.Image = global::FruiteCollectorProject.Properties.Resources.icons8_plum_48;
            this.plum.Location = new System.Drawing.Point(369, 90);
            this.plum.Name = "plum";
            this.plum.Size = new System.Drawing.Size(38, 35);
            this.plum.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.plum.TabIndex = 5;
            this.plum.TabStop = false;
            this.plum.Tag = "fruits";
            // 
            // mango
            // 
            this.mango.Image = global::FruiteCollectorProject.Properties.Resources.icons8_mango_48;
            this.mango.Location = new System.Drawing.Point(152, 234);
            this.mango.Name = "mango";
            this.mango.Size = new System.Drawing.Size(38, 35);
            this.mango.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.mango.TabIndex = 6;
            this.mango.TabStop = false;
            this.mango.Tag = "fruits";
            // 
            // cherry
            // 
            this.cherry.Image = global::FruiteCollectorProject.Properties.Resources.icons8_cherry_48;
            this.cherry.Location = new System.Drawing.Point(265, 308);
            this.cherry.Name = "cherry";
            this.cherry.Size = new System.Drawing.Size(38, 35);
            this.cherry.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.cherry.TabIndex = 7;
            this.cherry.TabStop = false;
            this.cherry.Tag = "fruits";
            // 
            // gametimer
            // 
            this.gametimer.Enabled = true;
            this.gametimer.Interval = 50;
            this.gametimer.Tick += new System.EventHandler(this.gametimer_Tick);
            // 
            // lemon
            // 
            this.lemon.Image = global::FruiteCollectorProject.Properties.Resources.citrus;
            this.lemon.Location = new System.Drawing.Point(152, 90);
            this.lemon.Name = "lemon";
            this.lemon.Size = new System.Drawing.Size(38, 35);
            this.lemon.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.lemon.TabIndex = 8;
            this.lemon.TabStop = false;
            this.lemon.Tag = "fruits";
            // 
            // peach
            // 
            this.peach.Image = global::FruiteCollectorProject.Properties.Resources.peach;
            this.peach.Location = new System.Drawing.Point(612, 369);
            this.peach.Name = "peach";
            this.peach.Size = new System.Drawing.Size(38, 35);
            this.peach.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.peach.TabIndex = 9;
            this.peach.TabStop = false;
            this.peach.Tag = "fruits";
            // 
            // guava
            // 
            this.guava.Image = global::FruiteCollectorProject.Properties.Resources.guava;
            this.guava.Location = new System.Drawing.Point(612, 90);
            this.guava.Name = "guava";
            this.guava.Size = new System.Drawing.Size(38, 35);
            this.guava.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.guava.TabIndex = 10;
            this.guava.TabStop = false;
            this.guava.Tag = "fruits";
            // 
            // banana
            // 
            this.banana.Image = global::FruiteCollectorProject.Properties.Resources.icons8_banana_48;
            this.banana.Location = new System.Drawing.Point(265, 161);
            this.banana.Name = "banana";
            this.banana.Size = new System.Drawing.Size(38, 35);
            this.banana.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.banana.TabIndex = 11;
            this.banana.TabStop = false;
            this.banana.Tag = "fruits";
            this.banana.Click += new System.EventHandler(this.banana_Click);
            // 
            // custardapple
            // 
            this.custardapple.Image = global::FruiteCollectorProject.Properties.Resources.custard_appel;
            this.custardapple.Location = new System.Drawing.Point(369, 234);
            this.custardapple.Name = "custardapple";
            this.custardapple.Size = new System.Drawing.Size(38, 35);
            this.custardapple.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.custardapple.TabIndex = 12;
            this.custardapple.TabStop = false;
            this.custardapple.Tag = "fruits";
            // 
            // rasberry
            // 
            this.rasberry.Image = global::FruiteCollectorProject.Properties.Resources.raspberry;
            this.rasberry.Location = new System.Drawing.Point(478, 308);
            this.rasberry.Name = "rasberry";
            this.rasberry.Size = new System.Drawing.Size(38, 35);
            this.rasberry.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.rasberry.TabIndex = 13;
            this.rasberry.TabStop = false;
            this.rasberry.Tag = "fruits";
            // 
            // durian
            // 
            this.durian.Image = global::FruiteCollectorProject.Properties.Resources.durian;
            this.durian.Location = new System.Drawing.Point(478, 161);
            this.durian.Name = "durian";
            this.durian.Size = new System.Drawing.Size(38, 35);
            this.durian.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.durian.TabIndex = 14;
            this.durian.TabStop = false;
            this.durian.Tag = "fruits";
            // 
            // papaya
            // 
            this.papaya.Image = global::FruiteCollectorProject.Properties.Resources.papaya1;
            this.papaya.Location = new System.Drawing.Point(50, 308);
            this.papaya.Name = "papaya";
            this.papaya.Size = new System.Drawing.Size(38, 35);
            this.papaya.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.papaya.TabIndex = 15;
            this.papaya.TabStop = false;
            this.papaya.Tag = "fruits";
            // 
            // lychee
            // 
            this.lychee.Image = global::FruiteCollectorProject.Properties.Resources.lychee1;
            this.lychee.Location = new System.Drawing.Point(50, 161);
            this.lychee.Name = "lychee";
            this.lychee.Size = new System.Drawing.Size(38, 35);
            this.lychee.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.lychee.TabIndex = 16;
            this.lychee.TabStop = false;
            this.lychee.Tag = "fruits";
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::FruiteCollectorProject.Properties.Resources.melon1;
            this.pictureBox1.Location = new System.Drawing.Point(369, 369);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(38, 35);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 17;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.Tag = "fruits";
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = global::FruiteCollectorProject.Properties.Resources.pineapple;
            this.pictureBox2.Location = new System.Drawing.Point(152, 369);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(38, 35);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox2.TabIndex = 18;
            this.pictureBox2.TabStop = false;
            this.pictureBox2.Tag = "fruits";
            // 
            // timeLabel
            // 
            this.timeLabel.AutoSize = true;
            this.timeLabel.Location = new System.Drawing.Point(8, 90);
            this.timeLabel.Name = "timeLabel";
            this.timeLabel.Size = new System.Drawing.Size(46, 17);
            this.timeLabel.TabIndex = 19;
            this.timeLabel.Text = "label1";
            // 
            // GameScreen
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::FruiteCollectorProject.Properties.Resources._12;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.timeLabel);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.lychee);
            this.Controls.Add(this.papaya);
            this.Controls.Add(this.durian);
            this.Controls.Add(this.rasberry);
            this.Controls.Add(this.custardapple);
            this.Controls.Add(this.banana);
            this.Controls.Add(this.guava);
            this.Controls.Add(this.peach);
            this.Controls.Add(this.lemon);
            this.Controls.Add(this.cherry);
            this.Controls.Add(this.mango);
            this.Controls.Add(this.plum);
            this.Controls.Add(this.strawberry);
            this.Controls.Add(this.scoregame);
            this.Controls.Add(this.basket);
            this.Controls.Add(this.GameName);
            this.Controls.Add(this.menuStrip1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MainMenuStrip = this.menuStrip1;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "GameScreen";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "FruitCollector";
            this.Load += new System.EventHandler(this.GameScreen_Load);
            this.KeyDown += new System.Windows.Forms.KeyEventHandler(this.GameScreen_KeyDown);
            this.KeyUp += new System.Windows.Forms.KeyEventHandler(this.GameScreen_KeyUp);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.basket)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.strawberry)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.plum)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.mango)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.cherry)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.lemon)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.peach)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.guava)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.banana)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.custardapple)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.rasberry)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.durian)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.papaya)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.lychee)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem gameToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem newToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem endToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem profileToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem currentToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem newToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem reportToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem statisticsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem historyToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem exitToolStripMenuItem;
        private System.Windows.Forms.Label GameName;
        private System.Windows.Forms.ContextMenuStrip contextMenuStrip1;
        private System.Windows.Forms.PictureBox basket;
        private System.Windows.Forms.Label scoregame;
        private System.Windows.Forms.PictureBox strawberry;
        private System.Windows.Forms.PictureBox plum;
        private System.Windows.Forms.PictureBox mango;
        private System.Windows.Forms.PictureBox cherry;
        private System.Windows.Forms.Timer gametimer;
        private System.Windows.Forms.PictureBox lemon;
        private System.Windows.Forms.PictureBox peach;
        private System.Windows.Forms.PictureBox guava;
        private System.Windows.Forms.PictureBox banana;
        private System.Windows.Forms.PictureBox custardapple;
        private System.Windows.Forms.PictureBox rasberry;
        private System.Windows.Forms.PictureBox durian;
        private System.Windows.Forms.PictureBox papaya;
        private System.Windows.Forms.PictureBox lychee;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.Label timeLabel;
    }
}

